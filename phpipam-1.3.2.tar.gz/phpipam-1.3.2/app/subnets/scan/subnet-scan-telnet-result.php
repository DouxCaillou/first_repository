<?php
/*
 * insert new hosts to database
 *******************************/

include("subnet-scan-icmp-result.php");