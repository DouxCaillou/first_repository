<?php

// Data Import Constants

# display icons and colors for actions
$icons = array();
$icons['add'] = "fa-plus";
$icons['edit'] = "fa-pencil";
$icons['skip'] = "fa-times";
$icons['error'] = "fa-times";
$colors = array();
$colors['add'] = "success";
$colors['edit'] = "info";
$colors['skip'] = "warning";
$colors['error'] = "danger";

?>